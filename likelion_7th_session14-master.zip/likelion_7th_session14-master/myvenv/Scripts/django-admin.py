#!c:\users\은교\desktop\은교\학교\동아리\멋쟁이 사자처럼\세션\과제\11주차\likelion_7th_session14\myvenv\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
